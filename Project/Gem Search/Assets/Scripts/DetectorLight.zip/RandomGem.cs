using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomGem : MonoBehaviour
{
  public GemDefinition GemDefinition;    

  // Start is called before the first frame update
  void Start()
  {
    GemDefinition[] gemDefs = Resources.FindObjectsOfTypeAll<GemDefinition>();

    GemDefinition = gemDefs[Random.Range(0, gemDefs.Length)];
  }

  // Update is called once per frame
  void Update()
  {
        
  }
}
